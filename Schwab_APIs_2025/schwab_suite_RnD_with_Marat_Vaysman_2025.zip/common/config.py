
"""
config.py
---------
Configuration helper to load environment variables and .env files safely.

This module centralizes configuration for all apps. It supports a MOCK mode by default
so examples run without live Schwab credentials.

Environment variables (per app's README for specifics):
- MOCK: "1" (default) to use synthetic data paths; "0" to enable live requests
- SCHWAB_CLIENT_ID / SCHWAB_CLIENT_SECRET
- SCHWAB_REDIRECT_URI (e.g., https://127.0.0.1)
- SCHWAB_TOKENS_FILE (default: ./tokens.json)
- KAFKA_BOOTSTRAP / KAFKA_SASL_* (optional)
- REDIS_URL (e.g., redis://localhost:6379/0)
"""

from __future__ import annotations
import os
from dotenv import load_dotenv
from loguru import logger

def load_env(dotenv_path: str | None = None) -> None:
    """Load .env file if present and log key flags.

    Args:
        dotenv_path: Optional explicit .env path.
    """
    try:
        load_dotenv(dotenv_path or ".env")
        logger.debug("Environment loaded (dotenv_path=%s)", dotenv_path or ".env")
    except Exception as e:
        logger.error("Failed to load .env: {}", e)

def get_bool(name: str, default: bool = False) -> bool:
    """Get a boolean environment variable with robust parsing."""
    try:
        val = os.getenv(name, str(default)).strip().lower()
        return val in ("1", "true", "yes", "y", "on")
    except Exception as e:
        logger.error("Error parsing bool env {}: {}", name, e)
        return default

def env(name: str, default: str | None = None) -> str | None:
    """Get env var with default and logging for critical keys."""
    try:
        value = os.getenv(name, default)
        if value is None:
            logger.debug("ENV {} not set; using default None", name)
        return value
    except Exception as e:
        logger.error("Error reading env {}: {}", name, e)
        return default
