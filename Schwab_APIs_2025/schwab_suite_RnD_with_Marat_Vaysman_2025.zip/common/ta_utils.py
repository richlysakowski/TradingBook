
"""
ta_utils.py
-----------
Technical indicators helpers. Uses pandas; will try to use pandas_ta if installed,
but falls back to simple implementations if not available.
"""
from __future__ import annotations
import pandas as pd
from loguru import logger

try:
    import pandas_ta as ta  # optional
    HAS_PTA = True
except Exception:
    HAS_PTA = False

def rsi(series: pd.Series, length: int = 14) -> pd.Series:
    try:
        if HAS_PTA:
            return ta.rsi(series, length=length)
        # fallback simple RSI
        delta = series.diff()
        gain = (delta.where(delta > 0, 0)).rolling(length).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(length).mean()
        rs = gain / (loss.replace(0, 1e-9))
        return 100 - (100 / (1 + rs))
    except Exception as e:
        logger.error("RSI calculation failed: {}", e)
        return pd.Series([None]*len(series), index=series.index)

def macd(series: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    try:
        if HAS_PTA:
            macd_df = ta.macd(series, fast=fast, slow=slow, signal=signal)
            return macd_df["MACD_12_26_9"], macd_df["MACDs_12_26_9"]
        ema_fast = series.ewm(span=fast, adjust=False).mean()
        ema_slow = series.ewm(span=slow, adjust=False).mean()
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=signal, adjust=False).mean()
        return macd_line, signal_line
    except Exception as e:
        logger.error("MACD calculation failed: {}", e)
        return series*0, series*0
