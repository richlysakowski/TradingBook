
"""
redis_utils.py
--------------
Redis connection and Pub/Sub helper with safe fallbacks.
"""
from __future__ import annotations
import os, json, time
from typing import Callable
from loguru import logger

def get_redis():
    try:
        import redis
        url = os.getenv("REDIS_URL","redis://localhost:6379/0")
        return redis.Redis.from_url(url, decode_responses=True)
    except Exception as e:
        logger.error("Redis unavailable: {}", e)
        return None

def publish(channel: str, message: dict) -> None:
    r = get_redis()
    if r is None:
        logger.warning("No Redis; skipping publish to {}", channel)
        return
    try:
        r.publish(channel, json.dumps(message))
    except Exception as e:
        logger.error("Redis publish failed: {}", e)

def subscribe(channel: str, handler: Callable[[dict], None]) -> None:
    r = get_redis()
    if r is None:
        logger.warning("No Redis; cannot subscribe to {}", channel)
        return
    try:
        p = r.pubsub()
        p.subscribe(channel)
        for m in p.listen():
            if m.get("type") == "message":
                try:
                    handler(json.loads(m["data"]))
                except Exception as e:
                    logger.error("Handler failed: {}", e)
    except Exception as e:
        logger.error("Redis subscribe error: {}", e)
