
"""
mock_data.py
------------
Deterministic synthetic data used when MOCK=1. Provides equities, options, futures,
forex ticks, book snapshots, and news items for demos that must run without credentials.
"""

from __future__ import annotations
import random
import time
import math
import itertools
from dataclasses import dataclass, asdict
from typing import List, Dict, Any
import datetime as dt

random.seed(42)

SP500 = ["AAPL","MSFT","AMZN","NVDA","META","GOOGL","GOOG","BRK.B","LLY","JPM",
         "V","TSLA","UNH","XOM","MA","HD","PG","AVGO","JNJ","COST","MRK","ABBV",
         "ORCL","CVX","KO","PEP","BAC","WMT","ASML","ADBE","CSCO","CRM","NFLX",
         "ACN","LIN","TXN","AMD","IBM","TMO","QCOM","INTU","AMAT","CMCSA","INTC"]

def _ts() -> str:
    return dt.datetime.utcnow().isoformat()

def gen_equity_tick(symbol: str, base: float = 100.0, vol: float = 0.5) -> Dict[str, Any]:
    """Generate a single synthetic equity tick."""
    try:
        drift = random.uniform(-vol, vol)
        price = round(base * (1 + drift/100), 2)
        bid = round(price - 0.02, 2)
        ask = round(price + 0.02, 2)
        return {
            "symbol": symbol,
            "ts": _ts(),
            "last": price,
            "bid": bid,
            "ask": ask,
            "volume": random.randint(1000, 50000),
            "halted": False,
        }
    except Exception as e:
        return {"error": f"gen_equity_tick failed for {symbol}: {e}"}

def gen_book_snapshot(symbol: str, base: float = 100.0) -> Dict[str, Any]:
    """Synthetic L2 snapshot with 10x10 depth."""
    try:
        levels = 10
        # Random walk spreads
        bids = [{"px": round(base - i*0.05 - random.uniform(0, 0.02), 2),
                 "qty": random.randint(50, 500)} for i in range(levels)]
        asks = [{"px": round(base + i*0.05 + random.uniform(0, 0.02), 2),
                 "qty": random.randint(50, 500)} for i in range(levels)]
        return {"symbol": symbol, "ts": _ts(), "bids": bids, "asks": asks}
    except Exception as e:
        return {"error": f"gen_book_snapshot failed for {symbol}: {e}"}

def gen_option_chain(symbol: str) -> Dict[str, Any]:
    """Simplified option chain with IV and OI deltas for radar demos."""
    try:
        expiries = [ (dt.date.today()+dt.timedelta(days=d)).isoformat()
                    for d in (7,14,30,60) ]
        strikes = [round(80+i*5,2) for i in range(12)]
        chain = []
        for exp in expiries:
            for k in strikes:
                chain.append({
                    "symbol": f"{symbol}_{exp}_{k}_C",
                    "underlying": symbol,
                    "expiry": exp,
                    "strike": k,
                    "type": "C",
                    "iv": round(random.uniform(0.2,0.6),3),
                    "oi": random.randint(100,5000),
                    "vol": random.randint(10,2000),
                    "delta": round(random.uniform(0.1,0.9),2)
                })
                chain.append({
                    "symbol": f"{symbol}_{exp}_{k}_P",
                    "underlying": symbol,
                    "expiry": exp,
                    "strike": k,
                    "type": "P",
                    "iv": round(random.uniform(0.2,0.6),3),
                    "oi": random.randint(100,5000),
                    "vol": random.randint(10,2000),
                    "delta": round(random.uniform(-0.9,-0.1),2)
                })
        return {"ts": _ts(), "underlying": symbol, "contracts": chain}
    except Exception as e:
        return {"error": f"gen_option_chain failed: {e}"}

def gen_futures_tick(symbol: str = "/ES") -> Dict[str, Any]:
    """Synthetic futures tick with volatility bursts."""
    try:
        base = 5000.0 if symbol == "/ES" else 18000.0
        burst = random.random() < 0.05
        move = random.uniform(-1.0, 1.0) * (5 if burst else 1)
        px = round(base + move, 2)
        return {"symbol": symbol, "ts": _ts(), "last": px, "burst": burst}
    except Exception as e:
        return {"error": f"gen_futures_tick failed: {e}"}

def gen_fx_tick(pair: str = "EURUSD") -> Dict[str, Any]:
    try:
        base = 1.1000 if pair == "EURUSD" else 156.00
        move = random.uniform(-0.001, 0.001)
        return {"symbol": pair, "ts": _ts(), "last": round(base + move, 5)}
    except Exception as e:
        return {"error": f"gen_fx_tick failed: {e}"}

def gen_news_item(symbol: str) -> Dict[str, Any]:
    try:
        headline = random.choice([
            "beats earnings estimates", "misses guidance", "announces buyback",
            "launches new product line", "executive change", "SEC filing update"
        ])
        return {"symbol": symbol, "ts": _ts(), "headline": f"{symbol} {headline}", "url": "https://example.com/news"}
    except Exception as e:
        return {"error": f"gen_news_item failed: {e}"}
