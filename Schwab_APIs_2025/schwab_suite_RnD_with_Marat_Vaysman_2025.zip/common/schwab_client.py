
"""
schwab_client.py
----------------
Abstraction over Schwab REST and Streaming (WebSocket) APIs with MOCK fallback.

- In MOCK mode (MOCK=1), generates synthetic data using mock_data.py.
- In LIVE mode (MOCK=0), performs authenticated REST calls and (optionally) uses websockets.
  For streaming, if `schwab-py` is installed, we can leverage its StreamClient.

This module avoids distributing secrets and guides the user with explicit error messages.
"""

from __future__ import annotations
import os, json, time, asyncio, base64
from typing import Any, Dict, List, Callable, Optional
from loguru import logger
import requests

from .config import get_bool, env
from . import mock_data

class SchwabError(Exception):
    """Domain-specific exception for Schwab client operations."""

class SchwabClient:
    """Lightweight client for REST + Streaming with mock fallback."""

    def __init__(self, tokens_path: str | None = None) -> None:
        try:
            self.mock = get_bool("MOCK", True)
            self.tokens_path = tokens_path or env("SCHWAB_TOKENS_FILE", "tokens.json")
            self.client_id = env("SCHWAB_CLIENT_ID")
            self.client_secret = env("SCHWAB_CLIENT_SECRET")
            self.redirect_uri = env("SCHWAB_REDIRECT_URI", "https://127.0.0.1")
            self.base_url = "https://api.schwabapi.com/v1"
            self.session = requests.Session()
            logger.info("SchwabClient initialized (mock={})", self.mock)
        except Exception as e:
            raise SchwabError(f"Failed to initialize SchwabClient: {e}")

    # ---------- Token Helpers ----------
    def _load_tokens(self) -> Dict[str, Any]:
        try:
            if not os.path.exists(self.tokens_path):
                raise SchwabError(f"tokens file not found: {self.tokens_path}")
            with open(self.tokens_path) as f:
                return json.load(f)
        except Exception as e:
            raise SchwabError(f"Failed to load tokens: {e}")

    def _auth_header(self) -> Dict[str, str]:
        try:
            tokens = self._load_tokens()
            at = tokens.get("access_token")
            if not at:
                raise SchwabError("access_token missing in tokens file")
            return {"Authorization": f"Bearer {at}"}
        except Exception as e:
            raise SchwabError(f"Failed to build auth header: {e}")

    # ---------- REST ----------
    def get_quote(self, symbol: str) -> Dict[str, Any]:
        """Get a single quote (mock or live)."""
        try:
            if self.mock:
                return mock_data.gen_equity_tick(symbol, base=100+hash(symbol)%200)
            url = f"{self.base_url}/{requests.utils.quote(symbol, safe='')}/quotes?fields=quote,fundamental"
            r = self.session.get(url, headers=self._auth_header(), timeout=15)
            if r.status_code != 200:
                raise SchwabError(f"quote failed {r.status_code}: {r.text}")
            return r.json()
        except Exception as e:
            raise SchwabError(f"get_quote error: {e}")

    def get_option_chain(self, symbol: str) -> Dict[str, Any]:
        try:
            if self.mock:
                return mock_data.gen_option_chain(symbol)
            # Example endpoint placeholder (adjust to real endpoint if available)
            url = f"{self.base_url}/markets/options/chains?symbol={requests.utils.quote(symbol)}"
            r = self.session.get(url, headers=self._auth_header(), timeout=20)
            if r.status_code != 200:
                raise SchwabError(f"option chain failed {r.status_code}: {r.text}")
            return r.json()
        except Exception as e:
            raise SchwabError(f"get_option_chain error: {e}")

    # ---------- Streaming (WebSocket) ----------
    async def stream_equities(self, symbols: List[str], on_message: Callable[[Dict[str, Any]], None]):
        """Stream L1 equities ticks. In MOCK mode, emits synthetic ticks every 1s."""
        try:
            if self.mock:
                while True:
                    for s in symbols:
                        on_message(mock_data.gen_equity_tick(s, base=100+hash(s)%200))
                    await asyncio.sleep(1.0)
            else:
                try:
                    # Attempt to use schwab-py if installed
                    from schwab.auth import easy_client
                    from schwab.client import Client
                    from schwab.streaming import StreamClient
                except Exception as e:
                    raise SchwabError("schwab-py is required for live streaming. Install with `pip install schwab-py`. Error: {}".format(e))
                # create client
                client = easy_client(api_key=self.client_id, app_secret=self.client_secret,
                                     callback_url=self.redirect_uri, token_path=self.tokens_path)
                stream_client = StreamClient(client, account_id=int(os.getenv("SCHWAB_ACCOUNT_ID","0") or "0"))
                await stream_client.login()
                def _h(msg): 
                    try:
                        on_message(msg)
                    except Exception as e:
                        logger.error("on_message handler failed: {}", e)
                stream_client.add_level_one_equities_handler(_h)
                await stream_client.level_one_equities_subs(symbols)
                while True:
                    await stream_client.handle_message()
        except Exception as e:
            raise SchwabError(f"stream_equities error: {e}")

    async def stream_book(self, symbol: str, on_message: Callable[[Dict[str, Any]], None]):
        """Stream order book depth (mock: snapshots every 2s)."""
        try:
            if self.mock:
                while True:
                    on_message(mock_data.gen_book_snapshot(symbol, base=100+hash(symbol)%200))
                    await asyncio.sleep(2.0)
            else:
                try:
                    from schwab.auth import easy_client
                    from schwab.streaming import StreamClient
                except Exception as e:
                    raise SchwabError("schwab-py required for live book stream. {}".format(e))
                client = easy_client(api_key=self.client_id, app_secret=self.client_secret,
                                     callback_url=self.redirect_uri, token_path=self.tokens_path)
                stream_client = StreamClient(client, account_id=int(os.getenv("SCHWAB_ACCOUNT_ID","0") or "0"))
                await stream_client.login()
                def _h(msg): 
                    try: on_message(msg)
                    except Exception as e: logger.error("handler failed: {}", e)
                stream_client.add_nasdaq_book_handler(_h)
                await stream_client.nasdaq_book_subs([symbol])
                while True:
                    await stream_client.handle_message()
        except Exception as e:
            raise SchwabError(f"stream_book error: {e}")
