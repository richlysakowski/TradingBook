
"""
kafka_utils.py
--------------
Helpers for producing and consuming Kafka messages using either kafka-python or confluent-kafka.
Falls back gracefully if neither is available.
"""
from __future__ import annotations
from typing import Optional, Dict, Any, Iterable, Callable
from loguru import logger
import os, json, time

def _cfg(prefix: str, default: str = "") -> str:
    return os.getenv(prefix, default)

def make_producer() -> Any:
    """Create a Kafka producer with best-effort library detection."""
    try:
        if _cfg("USE_CONFLUENT", "0") == "1":
            from confluent_kafka import Producer
            conf = {
                "bootstrap.servers": _cfg("KAFKA_BOOTSTRAP","localhost:9092"),
                "security.protocol": _cfg("KAFKA_SECURITY_PROTOCOL",""),
                "sasl.mechanism": _cfg("KAFKA_SASL_MECHANISM",""),
                "sasl.username": _cfg("KAFKA_SASL_USERNAME",""),
                "sasl.password": _cfg("KAFKA_SASL_PASSWORD",""),
            }
            return Producer({k:v for k,v in conf.items() if v})
        else:
            from kafka import KafkaProducer
            return KafkaProducer(
                bootstrap_servers=_cfg("KAFKA_BOOTSTRAP","localhost:9092"),
                value_serializer=lambda v: json.dumps(v).encode("utf-8")
            )
    except Exception as e:
        logger.error("Failed to create Kafka producer: {}", e)
        return None

def send(producer: Any, topic: str, value: Dict[str, Any]) -> None:
    try:
        if producer is None:
            logger.warning("Producer is None; skipping send to topic {}", topic)
            return
        if producer.__class__.__name__ == "Producer":
            producer.produce(topic, json.dumps(value).encode("utf-8"))
            producer.flush()
        else:
            producer.send(topic, value)
    except Exception as e:
        logger.error("Kafka send failed (topic={}): {}", topic, e)

def make_consumer(topics: Iterable[str]) -> Any:
    try:
        if _cfg("USE_CONFLUENT","0") == "1":
            from confluent_kafka import Consumer
            conf = {
                "bootstrap.servers": _cfg("KAFKA_BOOTSTRAP","localhost:9092"),
                "group.id": _cfg("KAFKA_GROUP","schwab-suite"),
                "auto.offset.reset": "latest",
                "security.protocol": _cfg("KAFKA_SECURITY_PROTOCOL",""),
                "sasl.mechanism": _cfg("KAFKA_SASL_MECHANISM",""),
                "sasl.username": _cfg("KAFKA_SASL_USERNAME",""),
                "sasl.password": _cfg("KAFKA_SASL_PASSWORD",""),
            }
            c = Consumer({k:v for k,v in conf.items() if v})
            c.subscribe(list(topics))
            return c
        else:
            from kafka import KafkaConsumer
            return KafkaConsumer(*topics, bootstrap_servers=_cfg("KAFKA_BOOTSTRAP","localhost:9092"),
                                 value_deserializer=lambda v: json.loads(v.decode("utf-8")))
    except Exception as e:
        logger.error("Failed to create Kafka consumer: {}", e)
        return None
