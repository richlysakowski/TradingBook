
# App 02 – News & Sentiment Alerting (S&P 500)

**Focus:** News-based alerts with naive sentiment.  
**Service:** FastAPI, publishes to Kafka + Redis.

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:api --reload --port 8091
```

## Use

- `POST /mock_burst?n=20` to simulate 20 news items.  
- Replace `gen_news_item` with your news provider for live data.
