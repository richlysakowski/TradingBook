
"""
App 02 - News & Sentiment Alerting (S&P 500)
--------------------------------------------
FastAPI service that fetches (mock) news for S&P 500 tickers, performs simple sentiment,
and publishes alerts. Replace mock with your preferred news API.

Run:
  pip install -r requirements.txt
  uvicorn app:api --reload --port 8091
"""
from __future__ import annotations
import os, time, json, asyncio, random
from typing import List, Dict, Any
from loguru import logger
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from common.config import load_env
from common.mock_data import SP500, gen_news_item
from common.kafka_utils import make_producer, send as kafka_send
from common.redis_utils import publish as redis_publish

load_env()
ALERT_TOPIC = os.getenv("NEWS_ALERT_TOPIC","schwab.news")

class NewsItem(BaseModel):
    symbol: str
    ts: str
    headline: str
    url: str

api = FastAPI(title="News & Sentiment Alerts")

def simple_sentiment(text: str) -> float:
    try:
        pos = sum(w in text.lower() for w in ["beat","buyback","launch","upgrade"])
        neg = sum(w in text.lower() for w in ["miss","downgrade","halt","sec"])
        score = pos - neg
        return float(score)
    except Exception as e:
        logger.error("simple_sentiment failed: {}", e)
        return 0.0

@api.get("/health")
def health():
    return {"status":"ok","time": time.time()}

@api.post("/ingest", response_model=Dict[str,Any])
def ingest(items: List[NewsItem]):
    try:
        producer = make_producer()
        count = 0
        for item in items:
            s = simple_sentiment(item.headline)
            payload = {"type":"news","symbol":item.symbol,"headline":item.headline,"sentiment":s,"url":item.url,"ts":item.ts}
            kafka_send(producer, ALERT_TOPIC, payload)
            redis_publish(ALERT_TOPIC, payload)
            count += 1
        return {"ingested": count}
    except Exception as e:
        logger.exception("ingest failed: {}", e)
        raise HTTPException(500, str(e))

@api.post("/mock_burst")
def mock_burst(n: int = 20):
    try:
        items = [NewsItem(**gen_news_item(random.choice(SP500[:50]))) for _ in range(n)]
        return ingest(items)
    except Exception as e:
        raise HTTPException(500, f"mock_burst failed: {e}")
