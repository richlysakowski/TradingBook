
# App 09 – Forex Spike Detector

**Focus:** FX (forex) streaming analysis (mock) with spike detection.  
**UI:** Streamlit.

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```
