
"""
App 09 - Forex Spike Detector
-----------------------------
Detects spikes in EURUSD/USDJPY using mock FX ticks. Streamlit UI signals spikes.

Run:
  pip install -r requirements.txt
  streamlit run app.py
"""
from __future__ import annotations
import os, asyncio, collections
import pandas as pd
import streamlit as st
from loguru import logger
from common.config import load_env
from common.mock_data import gen_fx_tick

load_env()
st.set_page_config(page_title="Forex Spike Detector", layout="wide")
PAIR = os.getenv("FX_PAIR","EURUSD")
WINDOW = 200
prices = collections.deque(maxlen=WINDOW)

async def main_async():
    placeholder = st.empty()
    while True:
        t = gen_fx_tick(PAIR)
        prices.append(t["last"])
        if len(prices)>=30:
            df = pd.DataFrame({"px": list(prices)})
            ret = df["px"].pct_change().rolling(5).sum()
            spike = ret.iloc[-1]
            with placeholder.container():
                st.line_chart(df["px"])
                if abs(spike) > 0.002:
                    st.error(f"{PAIR} Spike detected: {spike:.4%}")
        await asyncio.sleep(0.5)

def main():
    asyncio.run(main_async())

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.exception("Fatal error in App 09: {}", e)
