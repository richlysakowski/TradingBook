
# Schwab Streaming API: 12 Complete Applications (Equities, Options, Futures, Forex, Book Depth, Charting, Account Activity)

This repository contains **12 fully runnable Python applications** built around the **Schwab Streaming + REST APIs** (with a **Mock mode** so you can run *without* credentials). 
They demonstrate **S&P 500 unusual activity and news alerts** plus breadth across **equities, options, futures, forex, order book depth, charting, and account activity**.

## How to Use

1. **Install Python 3.10+** and optionally **Docker**.
2. `cd` into any app folder (e.g., `01_premarket_gap_scanner`) and follow its `README.md`.
3. Each app supports **MOCK=1** (default). To use live Schwab:
   - Set environment variables in a `.env` file (examples provided in each app).
   - Obtain API credentials from the Schwab Developer Portal and tokens file (`tokens.json`).
   - Install optional dependencies (Kafka, Redis) when needed.

## Shared Utilities

`common/` includes reusable modules:
- `config.py` – Loads env vars and `.env` with safe defaults.
- `schwab_client.py` – OAuth/token helper, HTTP requests, and **streaming** integration with **mock fallback**.
- `mock_data.py` – Deterministic synthetic data (equities, options, futures, FX, order book snapshots).
- `kafka_utils.py` – Kafka producer/consumer helpers (Confluent Cloud or local).
- `redis_utils.py` – Redis Pub/Sub helpers.
- `ta_utils.py` – Technical indicators using **pandas** (lightweight in mock) with opt-in **pandas_ta** if installed.

All apps import from `common` to avoid duplication and to maintain production-grade structure.

## Apps Overview

01. **Premarket Gap & Unusual Volume Scanner (S&P 500)** – Streamlit dashboard with alerts + Kafka/Redis publish.
02. **News & Sentiment Alerting (S&P 500)** – FastAPI service consuming external news API + rules engine, publishes alerts.
03. **Unusual Options Activity Radar** – Dash app with IV, OI deltas, and flow clustering; Redis + Kafka pipelines.
04. **Earnings-Day Anomaly Watcher** – Batch + stream hybrid; correlates earnings calendar with live moves and options skew.
05. **Equity Order Book Depth Heatmap** – Real-time L2/Book visualization + imbalance alerts.
06. **Streaming Technical Signal Board** – RSI/MACD/Bollinger on live prices with alert rules.
07. **Sector Breadth & Rotation Monitor** – S&P sector ETFs and adv/decline streaming; divergence alerts.
08. **Futures–Equities Divergence (ES vs SPY)** – Cross-asset signals + lead/lag detection; Kafka orchestration.
09. **Forex Spike Detector** – EURUSD, USDJPY volatility and breakouts; Streamlit app.
10. **Options Sentiment & Skew Monitor** – Term structure & skew analysis; publishes daily/real-time alerts.
11. **Account Activity & Risk Monitor** – Positions/PNL/Greeks snapshot + alerts; FastAPI + Web UI.
12. **Kafka-Orchestrated Multi-Topic Alert Hub** – Central hub aggregating all alerts; SQLAlchemy persistence; dashboard.

## Quick Start (Mock Mode)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r common/requirements_base.txt

# run any app in mock mode
cd 01_premarket_gap_scanner
python app.py
```

> For **live Schwab**, set the env vars listed in each app README and ensure `tokens.json` is present via your OAuth flow.

## License

For demonstration and educational use. Review and comply with Schwab API terms of use when using live data.
