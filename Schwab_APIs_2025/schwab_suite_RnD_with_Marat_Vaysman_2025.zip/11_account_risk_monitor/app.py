
"""
App 11 - Account Activity & Risk Monitor
----------------------------------------
FastAPI service exposing account snapshot and basic risk metrics (mocked unless live creds set).

Run:
  pip install -r requirements.txt
  uvicorn app:api --reload --port 8092
"""
from __future__ import annotations
import os, time, random
from typing import Dict, Any
from fastapi import FastAPI
from loguru import logger
from common.config import load_env

load_env()
api = FastAPI(title="Account Activity & Risk Monitor")

def get_positions() -> list[dict]:
    try:
        # mock positions
        syms = ["AAPL","MSFT","NVDA","SPY","TSLA"]
        return [{"symbol": s, "qty": random.randint(1,50), "avg_px": 100+hash(s)%200} for s in syms]
    except Exception as e:
        logger.error("get_positions failed: {}", e)
        return []

def compute_risk(positions: list[dict]) -> Dict[str, Any]:
    try:
        gross = sum(p["qty"]*p["avg_px"] for p in positions)
        # toy VaR
        var = 0.02 * gross
        return {"gross_exposure": gross, "toy_var": var}
    except Exception as e:
        logger.error("compute_risk failed: {}", e)
        return {"gross_exposure":0, "toy_var":0}

@api.get("/snapshot")
def snapshot():
    pos = get_positions()
    risk = compute_risk(pos)
    return {"positions": pos, "risk": risk, "ts": time.time()}
