
# App 11 – Account Activity & Risk Monitor

**Focus:** Account + risk (mock).  
**Service:** FastAPI.

## Run

```bash
pip install -r requirements.txt
uvicorn app:api --reload --port 8092
```
