
"""
App 10 - Options Sentiment & Skew Monitor
-----------------------------------------
Calculates simple put/call ratio and IV skew by expiration and flags changes.

Run:
  pip install -r requirements.txt
  python app.py
"""
from __future__ import annotations
import os, time
import pandas as pd
from loguru import logger
from common.config import load_env
from common.schwab_client import SchwabClient
from common.kafka_utils import make_producer, send as kafka_send

load_env()
ALERT_TOPIC = os.getenv("SKEW_TOPIC","schwab.skew")

def put_call_ratio(df: pd.DataFrame) -> float:
    try:
        puts = df[df["type"]=="P"]["vol"].sum()
        calls = df[df["type"]=="C"]["vol"].sum()
        return float(puts)/float(max(calls,1))
    except Exception as e:
        logger.error("put_call_ratio failed: {}", e)
        return 0.0

def iv_skew(df: pd.DataFrame) -> float:
    try:
        call_iv = df[df["type"]=="C"]["iv"].median()
        put_iv  = df[df["type"]=="P"]["iv"].median()
        return float(call_iv - put_iv)
    except Exception as e:
        logger.error("iv_skew failed: {}", e)
        return 0.0

def main():
    client = SchwabClient()
    sym = os.getenv("OPT_SYMBOL","AAPL")
    df = pd.DataFrame(client.get_option_chain(sym).get("contracts",[]))
    pcr = put_call_ratio(df)
    skew = iv_skew(df)
    print(f"{sym} Put/Call Ratio={pcr:.2f} | IV Skew={skew:.3f}")
    prod = make_producer()
    if pcr>1.5 or abs(skew)>0.1:
        kafka_send(prod, ALERT_TOPIC, {"type":"opt_sent_skew","symbol":sym,"pcr":pcr,"skew":skew,"ts": time.time()})

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.exception("Fatal error in App 10: {}", e)
