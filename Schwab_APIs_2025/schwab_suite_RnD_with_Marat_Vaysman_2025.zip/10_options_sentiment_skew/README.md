
# App 10 – Options Sentiment & Skew Monitor

**Focus:** Options (PCR & IV skew).  
**Pipelines:** Kafka alerts.

## Run

```bash
pip install -r requirements.txt
python app.py
```
