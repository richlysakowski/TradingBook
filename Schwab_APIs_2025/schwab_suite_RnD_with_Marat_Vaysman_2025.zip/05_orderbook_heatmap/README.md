
# App 05 – Equity Order Book Depth Heatmap

**Focus:** L2/Book depth and imbalance alerting (equities).

## Run

```bash
pip install -r requirements.txt
python app.py  # set BOOK_SYMBOL if desired
```
