
"""
App 05 - Equity Order Book Depth Heatmap
----------------------------------------
Streams order book snapshots (mock or live via schwab-py) and renders a heatmap-like printout,
plus imbalance alerts.

Run:
  pip install -r requirements.txt
  python app.py
"""
from __future__ import annotations
import os, asyncio, time
from loguru import logger
from common.config import load_env
from common.schwab_client import SchwabClient

load_env()

def imbalance(snapshot: dict) -> float:
    try:
        bid_qty = sum(l["qty"] for l in snapshot.get("bids",[]))
        ask_qty = sum(l["qty"] for l in snapshot.get("asks",[]))
        if bid_qty+ask_qty == 0: return 0.0
        return round(100*(bid_qty-ask_qty)/(bid_qty+ask_qty), 2)
    except Exception as e:
        logger.error("imbalance failed: {}", e)
        return 0.0

async def main_async(symbol: str):
    client = SchwabClient()
    async def on_msg(msg: dict):
        if "bids" in msg and "asks" in msg:
            imb = imbalance(msg)
            print(f"[{msg['ts']}] {msg['symbol']} Imbalance: {imb:+.2f}% | Top Bid {msg['bids'][0]['px']} / Ask {msg['asks'][0]['px']}")
        else:
            print(msg)
    await client.stream_book(symbol, on_msg)

def main():
    symbol = os.getenv("BOOK_SYMBOL","AAPL")
    asyncio.run(main_async(symbol))

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.exception("Fatal error in App 05: {}", e)
