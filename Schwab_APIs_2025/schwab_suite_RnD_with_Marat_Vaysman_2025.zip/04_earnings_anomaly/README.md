
# App 04 – Earnings-Day Anomaly Watcher

**Focus:** Earnings + price surprise alerts.  
**Type:** Batch + short-lived monitoring (can be cron).

## Run

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
