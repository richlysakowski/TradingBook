
"""
App 04 - Earnings-Day Anomaly Watcher
-------------------------------------
Batch + stream hybrid. Loads a mock earnings calendar, monitors live ticks for those tickers,
and raises alerts when moves exceed thresholds or options skew widens.

Run:
  pip install -r requirements.txt
  python app.py
"""
from __future__ import annotations
import os, asyncio, time, json, random
import pandas as pd
from loguru import logger
from common.config import load_env
from common.schwab_client import SchwabClient
from common.kafka_utils import make_producer, send as kafka_send

load_env()
ALERT_TOPIC = os.getenv("EARNINGS_TOPIC","schwab.earnings")

def load_calendar() -> pd.DataFrame:
    """Mock earnings calendar."""
    try:
        tickers = ["AAPL","MSFT","NVDA","AMZN","META","TSLA"]
        dates = [pd.Timestamp.today().normalize() for _ in tickers]
        return pd.DataFrame({"symbol": tickers, "date": dates})
    except Exception as e:
        logger.error("load_calendar failed: {}", e)
        return pd.DataFrame(columns=["symbol","date"])

async def monitor(client: SchwabClient, symbols):
    producer = make_producer()
    for s in symbols:
        try:
            q = client.get_quote(s)
            last = q.get("last") or q.get(s,{}).get("quote",{}).get("lastPrice", 0.0)
            move = (last % 10) - 5  # synthetic surprise metric
            if abs(move) > 3.0:
                payload = {"type":"earnings_move","symbol":s,"last":last,"move_score":move,"ts": time.time()}
                kafka_send(producer, ALERT_TOPIC, payload)
                logger.info("Earnings anomaly: {}", payload)
        except Exception as e:
            logger.error("monitor failed for {}: {}", s, e)

def main():
    client = SchwabClient()
    cal = load_calendar()
    asyncio.run(monitor(client, cal["symbol"].tolist()))

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.exception("Fatal error in App 04: {}", e)
