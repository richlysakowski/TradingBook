
"""
App 06 - Streaming Technical Signal Board
-----------------------------------------
Stream (mock) ticks, compute RSI/MACD via ta_utils, and display signals in Streamlit.

Run:
  pip install -r requirements.txt
  streamlit run app.py
"""
from __future__ import annotations
import os, asyncio, collections, time
import pandas as pd
from loguru import logger
import streamlit as st
from common.config import load_env
from common.schwab_client import SchwabClient
from common.ta_utils import rsi, macd

load_env()
st.set_page_config(page_title="Streaming Signal Board", layout="wide")
st.title("Streaming Technical Signal Board")

SYMBOL = os.getenv("TECH_SYMBOL","MSFT")
WINDOW = int(os.getenv("TECH_WINDOW","200"))

prices = collections.deque(maxlen=WINDOW)

async def main_async():
    client = SchwabClient()
    placeholder = st.empty()

    def on_msg(msg: dict):
        last = msg.get("last") or msg.get(SYMBOL,{}).get("quote",{}).get("lastPrice", None)
        if last is None: return
        prices.append(last)
        if len(prices) >= 50:
            df = pd.DataFrame({"close": list(prices)})
            df["rsi"] = rsi(df["close"], 14)
            macd_line, signal_line = macd(df["close"])
            df["macd"] = macd_line
            df["signal"] = signal_line
            latest = df.iloc[-1]
            signal_msg = f"RSI={latest['rsi']:.1f} | MACD={latest['macd']:.3f} vs Signal={latest['signal']:.3f}"
            with placeholder.container():
                st.line_chart(df[["close","rsi","macd","signal"]])
                st.success(signal_msg)

    await client.stream_equities([SYMBOL], on_msg)

def main():
    asyncio.run(main_async())

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.exception("Fatal error in App 06: {}", e)
