
# App 06 – Streaming Technical Signal Board

**Focus:** Charting + technical analysis (equities).  
**UI:** Streamlit.

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```
