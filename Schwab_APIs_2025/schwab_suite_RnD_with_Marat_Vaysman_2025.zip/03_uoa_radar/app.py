
"""
App 03 - Unusual Options Activity Radar
---------------------------------------
Dash app that visualizes option chain IV vs OI/Vol and flags unusual activity.
Kafka producer publishes UOA alerts.

Run:
  pip install -r requirements.txt
  python app.py
"""
from __future__ import annotations
import os, json, time
import pandas as pd
from loguru import logger
from dash import Dash, dcc, html, Input, Output
from common.config import load_env
from common.schwab_client import SchwabClient
from common.kafka_utils import make_producer, send as kafka_send

load_env()
ALERT_TOPIC = os.getenv("UOA_TOPIC","schwab.uoa")

def to_df(chain: dict) -> pd.DataFrame:
    try:
        df = pd.DataFrame(chain.get("contracts", []))
        return df
    except Exception as e:
        logger.error("to_df failed: {}", e)
        return pd.DataFrame()

def unusual(df: pd.DataFrame) -> pd.DataFrame:
    try:
        return df[(df["vol"] > df["oi"]*0.8) & (df["iv"] > df["iv"].median())]
    except Exception as e:
        logger.error("unusual filter failed: {}", e)
        return df.head(0)

def main():
    client = SchwabClient()
    app = Dash(__name__)
    app.layout = html.Div([
        html.H2("Unusual Options Activity Radar"),
        dcc.Input(id="symbol", type="text", value="AAPL"),
        html.Button("Load Chain", id="load"),
        dcc.Graph(id="scatter"),
        html.Div(id="status")
    ])

    @app.callback(Output("scatter","figure"), Output("status","children"),
                  Input("load","n_clicks"), Input("symbol","value"))
    def load_chain(n, sym):
        try:
            chain = client.get_option_chain(sym.strip().upper())
            df = to_df(chain)
            u = unusual(df)
            prod = make_producer()
            for _, row in u.iterrows():
                kafka_send(prod, ALERT_TOPIC, {"type":"uoa","symbol":sym,"expiry":row["expiry"],"strike":row["strike"],"iv":row["iv"],"oi":int(row["oi"]),"vol":int(row["vol"]), "ts":time.time()})
            fig = {
                "data":[{
                    "x": df["iv"], "y": df["vol"], "mode":"markers",
                    "text": df["symbol"], "name":"All"
                },{
                    "x": u["iv"], "y": u["vol"], "mode":"markers",
                    "text": u["symbol"], "name":"Unusual"
                }],
                "layout":{"title": f"IV vs Volume for {sym}"}
            }
            return fig, f"{len(u)} unusual contracts flagged."
        except Exception as e:
            logger.exception("load_chain failed: {}", e)
            return {"data":[],"layout":{"title":"Error"}}, str(e)

    app.run_server(host="0.0.0.0", port=8050, debug=False)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.exception("Fatal error in App 03: {}", e)
