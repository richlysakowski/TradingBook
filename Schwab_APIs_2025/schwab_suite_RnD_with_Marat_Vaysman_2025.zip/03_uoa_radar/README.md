
# App 03 – Unusual Options Activity Radar

**Focus:** Options analytics (IV vs Volume vs OI).  
**UI:** Dash.

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
