
# App 01 – Premarket Gap & Unusual Volume Scanner (S&P 500)

**Focus:** Equities + unusual activity alerts.  
**UI:** Streamlit (optional).  
**Pipelines:** Publishes alerts to Redis & Kafka topics (`schwab.alerts`).

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# Mock mode (default)
export USE_STREAMLIT=1
python app.py        # CLI
streamlit run app.py # UI
```

### Live Schwab (optional)

Set in `.env`:
```
MOCK=0
SCHWAB_CLIENT_ID=...
SCHWAB_CLIENT_SECRET=...
SCHWAB_REDIRECT_URI=https://127.0.0.1
SCHWAB_TOKENS_FILE=../tokens.json
SCHWAB_ACCOUNT_ID=YOUR_HASHED_ID
```

## What it does

- Scans a subset of S&P 500 for **premarket gaps** and **unusual volume**.
- Publishes top alerts to **Kafka** and **Redis**.
- Works without credentials in **MOCK** mode.

## Run

- `streamlit run app.py` for UI or `python app.py` for CLI.
