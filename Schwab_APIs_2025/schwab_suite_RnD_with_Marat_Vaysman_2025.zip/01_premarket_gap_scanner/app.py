
"""
App 01 - Premarket Gap & Unusual Volume Scanner (S&P 500)
----------------------------------------------------------
Streamlit app that scans S&P 500 for premarket gaps and unusual (synthetic or live) volume.
Publishes alerts to Kafka and Redis.

Run:
  pip install -r requirements.txt
  streamlit run app.py   # or python app.py (basic CLI)
"""
from __future__ import annotations
import os, asyncio, json, time
from typing import List, Dict, Any
from loguru import logger
import pandas as pd

# Optional GUI
USE_STREAMLIT = os.getenv("USE_STREAMLIT","1") == "1"
if USE_STREAMLIT:
    import streamlit as st

from common.config import load_env, get_bool
from common.mock_data import SP500, gen_equity_tick, gen_news_item
from common.schwab_client import SchwabClient, SchwabError
from common.kafka_utils import make_producer, send as kafka_send
from common.redis_utils import publish as redis_publish

load_env()

ALERT_TOPIC = os.getenv("ALERT_TOPIC","schwab.alerts")

def compute_gap(prev_close: float, current: float) -> float:
    try:
        if prev_close <= 0: return 0.0
        return round(100*(current - prev_close)/prev_close, 2)
    except Exception as e:
        logger.error("compute_gap failed: {}", e)
        return 0.0

def unusual_volume(vol: int, avg: int = 10000) -> bool:
    try:
        return vol > 3 * avg
    except Exception as e:
        logger.error("unusual_volume failed: {}", e)
        return False

def alert(symbol: str, last: float, gap: float, vol: int, extra: Dict[str,Any]|None=None) -> Dict[str,Any]:
    try:
        payload = {"type":"premarket_gap","symbol":symbol,"last":last,"gap_pct":gap,"vol":vol, "ts": time.time()}
        if extra: payload.update(extra)
        return payload
    except Exception as e:
        logger.error("alert build failed: {}", e)
        return {"error": str(e)}

def publish_alert(payload: Dict[str,Any]) -> None:
    try:
        producer = make_producer()
        kafka_send(producer, ALERT_TOPIC, payload)
        redis_publish(ALERT_TOPIC, payload)
    except Exception as e:
        logger.error("publish_alert failed: {}", e)

def scan_once(client: SchwabClient, universe: List[str]) -> pd.DataFrame:
    rows = []
    for sym in universe:
        try:
            q = client.get_quote(sym)
            if "error" in q: 
                logger.warning("Quote error for {}: {}", sym, q["error"])
                continue
            # normalizing mock vs live
            last = q.get("last") or q.get(sym,{}).get("quote",{}).get("lastPrice", 0.0)
            vol  = q.get("volume") or q.get(sym,{}).get("quote",{}).get("totalVolume", 0)
            prev = last * (1 - (0.02 if hash(sym)%2==0 else -0.01))  # synthetic prev close
            gap = compute_gap(prev, last)
            rows.append({"symbol": sym, "last": last, "volume": vol, "prev_close": prev, "gap_pct": gap})
        except SchwabError as e:
            logger.error("scan_once SchwabError for {}: {}", sym, e)
        except Exception as e:
            logger.error("scan_once error for {}: {}", sym, e)
    return pd.DataFrame(rows).sort_values("gap_pct", ascending=False)

def main():
    load_env()
    client = SchwabClient()
    universe = SP500[:50]  # demo subset; adjust as needed

    if USE_STREAMLIT:
        st.set_page_config(page_title="S&P 500 Premarket Gap Scanner", layout="wide")
        st.title("S&P 500 Premarket Gap & Unusual Volume Scanner")
        st.caption("MOCK mode defaults to ON. Set MOCK=0 to use live Schwab credentials.")

        if st.button("Scan Now"):
            df = scan_once(client, universe)
            st.dataframe(df, use_container_width=True)
            # publish top 5 alerts
            for _, row in df.head(5).iterrows():
                if unusual_volume(int(row["volume"])) or abs(row["gap_pct"]) >= 2.0:
                    payload = alert(row["symbol"], row["last"], row["gap_pct"], int(row["volume"]))
                    publish_alert(payload)
                    st.success(f"Alert published: {payload}")
        st.stop()

    # CLI mode
    df = scan_once(client, universe)
    print(df.head(20).to_string(index=False))

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.exception("Fatal error in App 01: {}", e)
