
# App 07 – Sector Breadth & Rotation Monitor

**Focus:** Equities breadth (sector ETFs) + divergence alerts.

## Run

```bash
pip install -r requirements.txt
python app.py
```
