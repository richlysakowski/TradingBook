
"""
App 07 - Sector Breadth & Rotation Monitor
------------------------------------------
Watches sector ETF universe (XLY, XLP, XLE, XLK, etc.) and computes advancing/declining breadth.
Publishes divergence alerts via Kafka.

Run:
  pip install -r requirements.txt
  python app.py
"""
from __future__ import annotations
import os, time
import pandas as pd
from loguru import logger
from common.config import load_env
from common.schwab_client import SchwabClient
from common.kafka_utils import make_producer, send as kafka_send

load_env()
ALERT_TOPIC = os.getenv("SECTOR_TOPIC","schwab.sector")
SECTORS = ["XLY","XLP","XLE","XLF","XLV","XLI","XLK","XLB","XLU","XLRE","XLC"]

def check_divergence(df: pd.DataFrame) -> pd.DataFrame:
    try:
        median = df["change"].median()
        return df[df["change"]*median < 0]  # names moving against median
    except Exception as e:
        logger.error("check_divergence failed: {}", e)
        return df.head(0)

def main():
    client = SchwabClient()
    rows = []
    for s in SECTORS:
        try:
            q = client.get_quote(s)
            last = q.get("last") or q.get(s,{}).get("quote",{}).get("lastPrice", 0.0)
            prev = last*(0.99 if hash(s)%2==0 else 1.01)
            chg = (last-prev)/prev*100 if prev else 0
            rows.append({"symbol": s, "last": last, "change": chg})
        except Exception as e:
            logger.error("sector quote failed for {}: {}", s, e)
    df = pd.DataFrame(rows).sort_values("change", ascending=False)
    print(df.to_string(index=False))

    div = check_divergence(df)
    prod = make_producer()
    for _, row in div.iterrows():
        kafka_send(prod, ALERT_TOPIC, {"type":"sector_div","symbol":row["symbol"],"change":row["change"],"ts": time.time()})

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.exception("Fatal error in App 07: {}", e)
