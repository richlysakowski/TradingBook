
"""
App 08 - Futures–Equities Divergence (ES vs SPY)
-----------------------------------------------
Compares /ES (or /MES) futures vs SPY for lead/lag and divergence alerts. Publishes to Kafka.

Run:
  pip install -r requirements.txt
  python app.py
"""
from __future__ import annotations
import os, asyncio, collections, time
import pandas as pd
from loguru import logger
from common.config import load_env
from common.mock_data import gen_futures_tick
from common.schwab_client import SchwabClient
from common.kafka_utils import make_producer, send as kafka_send

load_env()
ALERT_TOPIC = os.getenv("FUT_EQ_TOPIC","schwab.fut_eq")

WINDOW = 120
es_prices = collections.deque(maxlen=WINDOW)
spy_prices = collections.deque(maxlen=WINDOW)

async def main_async():
    client = SchwabClient()
    prod = make_producer()

    def on_spy(msg: dict):
        last = msg.get("last") or msg.get("SPY",{}).get("quote",{}).get("lastPrice", None)
        if last: spy_prices.append(float(last))

    async def stream_spy():
        await client.stream_equities(["SPY"], on_spy)

    async def stream_es():
        # Using mock for futures tick; replace with real when available
        while True:
            t = gen_futures_tick("/ES")
            es_prices.append(t["last"])
            await asyncio.sleep(1)

    async def monitor():
        while True:
            if len(es_prices)>30 and len(spy_prices)>30:
                es_ret = (es_prices[-1]-es_prices[-30])/es_prices[-30]
                spy_ret = (spy_prices[-1]-spy_prices[-30])/spy_prices[-30]
                div = es_ret - spy_ret
                if abs(div) > 0.002:
                    payload = {"type":"fut_eq_div","divergence":div,"es_ret":es_ret,"spy_ret":spy_ret,"ts": time.time()}
                    kafka_send(prod, ALERT_TOPIC, payload)
                    print("ALERT", payload)
            await asyncio.sleep(2)

    await asyncio.gather(stream_spy(), stream_es(), monitor())

def main():
    asyncio.run(main_async())

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.exception("Fatal error in App 08: {}", e)
