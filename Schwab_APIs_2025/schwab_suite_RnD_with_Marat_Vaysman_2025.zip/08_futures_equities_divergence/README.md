
# App 08 – Futures–Equities Divergence (ES vs SPY)

**Focus:** Cross-asset (futures vs equities) divergence detection.  
**Pipelines:** Kafka alerts.

## Run

```bash
pip install -r requirements.txt
python app.py
```
