
"""
App 12 - Kafka-Orchestrated Multi-Topic Alert Hub
--------------------------------------------------
Consumes alerts from multiple topics, persists to SQLite via SQLAlchemy, and serves a simple
Streamlit dashboard to explore alert history.

Run:
  pip install -r requirements.txt
  python app.py  # CLI consumer
  # OR
  streamlit run app.py  # dashboard
"""
from __future__ import annotations
import os, threading, time, json, sqlite3, queue
from typing import Iterable
from loguru import logger
import streamlit as st
from common.config import load_env
from common.kafka_utils import make_consumer

load_env()
TOPICS = os.getenv("ALERT_TOPICS","schwab.alerts,schwab.uoa,schwab.earnings,schwab.sector,schwab.fut_eq,schwab.skew").split(",")
DB_PATH = os.getenv("ALERT_DB","alerts.db")
UI = os.getenv("ALERT_UI","1") == "1"

def init_db():
    try:
        con = sqlite3.connect(DB_PATH)
        con.execute("""CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL, topic TEXT, payload TEXT
        )""")
        con.commit(); con.close()
    except Exception as e:
        logger.error("init_db failed: {}", e)

def write_alert(topic: str, payload: dict):
    try:
        con = sqlite3.connect(DB_PATH)
        con.execute("INSERT INTO alerts(ts, topic, payload) VALUES (?, ?, ?)", (payload.get("ts", time.time()), topic, json.dumps(payload)))
        con.commit(); con.close()
    except Exception as e:
        logger.error("write_alert failed: {}", e)

def consumer_loop(stop_ev: threading.Event):
    c = make_consumer(TOPICS)
    if c is None:
        logger.warning("No Kafka consumer available; exiting consumer loop.")
        return
    try:
        while not stop_ev.is_set():
            if c.__class__.__name__ == "Consumer":
                msg = c.poll(0.5)
                if msg and not msg.error():
                    payload = json.loads(msg.value().decode())
                    write_alert(msg.topic(), payload)
            else:
                for m in c.poll(timeout_ms=500) or []:
                    write_alert(m.topic, m.value)
    except Exception as e:
        logger.error("consumer_loop error: {}", e)

def ui_loop():
    st.set_page_config(page_title="Alert Hub", layout="wide")
    st.title("Kafka-Orchestrated Alert Hub")
    st.caption("Viewing alerts from: " + ", ".join(TOPICS))
    import pandas as pd
    if not os.path.exists(DB_PATH):
        st.warning("No DB yet. Start consumer first.")
        st.stop()
    con = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query("SELECT ts, topic, payload FROM alerts ORDER BY ts DESC LIMIT 500", con)
    if not df.empty:
        df["payload"] = df["payload"].apply(json.loads)
        st.dataframe(df, use_container_width=True)
    else:
        st.info("No alerts yet.")
    con.close()

def main():
    init_db()
    if UI:
        ui_loop()
    else:
        stop = threading.Event()
        t = threading.Thread(target=consumer_loop, args=(stop,), daemon=True)
        t.start()
        try:
            while True: time.sleep(1)
        except KeyboardInterrupt:
            stop.set()

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.exception("Fatal error in App 12: {}", e)
