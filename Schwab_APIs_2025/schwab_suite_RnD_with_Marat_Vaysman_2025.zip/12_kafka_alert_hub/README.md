
# App 12 – Kafka-Orchestrated Multi-Topic Alert Hub

**Focus:** Central alert persistence and dashboard.  
**Storage:** SQLite (for demo).  
**UI:** Streamlit optional; CLI consumer default with `ALERT_UI=0`.

## Run

```bash
pip install -r requirements.txt
# Start consumer (CLI)
ALERT_UI=0 python app.py

# In another shell, view dashboard
streamlit run app.py
```
